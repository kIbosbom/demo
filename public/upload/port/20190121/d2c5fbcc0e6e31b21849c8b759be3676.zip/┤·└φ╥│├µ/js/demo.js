
//Regional开始
$(document).ready(function(){
    $(".Regional").click(function(){
        if ($('.grade-eject').hasClass('grade-w-roll')) {
            $('.grade-eject').removeClass('grade-w-roll');
			$(this).removeClass('current');
            $('.screening').attr('style',' ');
            $('.kongbai').css('display','none');
            $('.grade-eject').css('display','none')
           
        } else {
            $('.grade-eject').addClass('grade-w-roll');         
			$(this).addClass('current');
			$(".Brand").removeClass('current');
			$(".Sort").removeClass('current');
            $('.kongbai').css('display','block');
            $('.grade-eject').css('display','block')
        }
    });
});



//Brand开始

$(document).ready(function(){
    $(".Brand").click(function(){
        if ($('.Category-eject').hasClass('grade-w-roll')) {
            $('.Category-eject').removeClass('grade-w-roll');
			$(this).removeClass('current');
            $('.screening').attr('style',' ');
            $('.kongbai').css('display','none');
            $('.Category-eject').css('display','none');
          
        } else {
            $('.Category-eject').addClass('grade-w-roll');
			$(this).addClass('current');
			$(".meishi").removeClass('current');
			$(".Regional").removeClass('current');
			$(".Sort").removeClass('current');
            $('.kongbai').css('display','block');
            $('.Category-eject').css('display','block');
    
        }
    });
});



//Sort开始

$(document).ready(function(){
    $(".Sort").click(function(){
        if ($('.Sort-eject').hasClass('grade-w-roll')) {
            $('.Sort-eject').removeClass('grade-w-roll');
			$(this).removeClass('current');
            $('.screening').attr('style',' ');
            $('.kongbai').css('display','none');
            $('.Sort-eject').css('display','none');
        } else {
            $('.Sort-eject').addClass('grade-w-roll');
			$(this).addClass('current');
			$(".meishi").removeClass('current');
			$(".Regional").removeClass('current');
			$(".Brand").removeClass('current');
            // $('.screening').attr('style','position: fixed;top:38px  ;');
            $('.kongbai').css('display','block');
            $('.Sort-eject').css('display','block');
        }
    });
});


//点击空白事件
$(document).ready(function(){
    $(".kongbai").click(function(){
        $('.Sort-eject').removeClass('grade-w-roll');
        $('.Category-eject').removeClass('grade-w-roll');
        $('.grade-eject').removeClass('grade-w-roll');
        $('.kongbai').css('display','none');
        $('.screening').attr('style',' ');
    })
})

//判断页面是否有弹出







$(document).ready(function(){
    $(".Regional").click(function(){
        if ($('.Category-eject').hasClass('grade-w-roll')){
            $('.Category-eject').removeClass('grade-w-roll');
        };
    });
});
$(document).ready(function(){
    $(".Regional").click(function(){
        if ($('.Sort-eject').hasClass('grade-w-roll')){
            $('.Sort-eject').removeClass('grade-w-roll');
        };
    });
});
$(document).ready(function(){
    $(".Regional").click(function(){
        if ($('.meishi22').hasClass('grade-w-roll')){
            $('.meishi22').removeClass('grade-w-roll');
        };

    });
});
$




$(document).ready(function(){
    $(".Brand").click(function(){
        if ($('.Sort-eject').hasClass('grade-w-roll')){
            $('.Sort-eject').removeClass('grade-w-roll');
        };
    });
});
$(document).ready(function(){
    $(".Brand").click(function(){
        if ($('.grade-eject').hasClass('grade-w-roll')){
            $('.grade-eject').removeClass('grade-w-roll');
        };
    });
});
$(document).ready(function(){
    $(".Brand").click(function(){
        if ($('.meishi22').hasClass('grade-w-roll')){
            $('.meishi22').removeClass('grade-w-roll');
        };
    });
});





$(document).ready(function(){
    $(".Sort").click(function(){
        if ($('.Category-eject').hasClass('grade-w-roll')){
            $('.Category-eject').removeClass('grade-w-roll');
        };
    });
});
$(document).ready(function(){
    $(".Sort").click(function(){
        if ($('.grade-eject').hasClass('grade-w-roll')){
            $('.grade-eject').removeClass('grade-w-roll');
        };

    });
});
$(document).ready(function(){
    $(".Sort").click(function(){
        if ($('.meishi22').hasClass('grade-w-roll')){
            $('.meishi22').removeClass('grade-w-roll');
        };

    });
});

$(document).ready(function(){
    $(".kongbai").click(function(){
       
    });
});


//点击li赋值
$(document).ready(function(){
$(".grade-w li").click(function(){
    
    var text1=$(this).text();
    $(".job").html(text1);
    $('.grade-eject').removeClass('grade-w-roll');
    $('.kongbai').css('display','none');
    $('.screening').attr('style',' ');
    });
})

$(document).ready(function(){
    $(".Sort-Sort li").click(function(){
        
        var text1=$(this).text();
        $(".paixu").html(text1);
        $('.Sort-eject').removeClass('grade-w-roll');
        $('.kongbai').css('display','none');
        $('.screening').attr('style',' ');
        });
    })

$(document).ready(function(){
        $(".Category-w li").click(function(){
            
            var text1=$(this).text();
            $(".shaixuan").html(text1);
            $('.Category-eject').removeClass('grade-w-roll');
            $('.kongbai').css('display','none');
            $('.screening').attr('style',' ');
            });
        })    

//首页左上角


    






